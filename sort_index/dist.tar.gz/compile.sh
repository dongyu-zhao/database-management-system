gcc main.c -o main -std=c99
