gcc main.c -o main.out -std=c99
